const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const blogRoutes = require("./routes/blogRoutes");

const app = express();
app.set("view engine", "ejs");
app.use(express.static("public"));
app.use(bodyParser.urlencoded({ extended: true }));

mongoose.connect("mongodb://localhost:27017/blogDB");

app.use("/", blogRoutes);

app.listen(3000, () => {
  console.log("Server started at http://localhost:3000");
});


