document.addEventListener("DOMContentLoaded", () => {
  console.log("Blog JS loaded!");
});
document.querySelectorAll(".post-link").forEach(link => {
  link.addEventListener("click", (event) => {
    event.preventDefault();
    const postId = link.getAttribute("data-id");
    fetch(`/post/${postId}`)
      .then(response => response.text())
      .then(html => {
        document.querySelector("#post-content").innerHTML = html;
      })
      .catch(error => console.error("Error fetching post:", error));
  });
});
document.querySelector("#login-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const username = document.querySelector("#username").value;
  const password = document.querySelector("#password").value;

  fetch("/login", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ username, password })
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      window.location.href = "/dashboard";
    } else {
      alert("Invalid credentials");
    }
  })
  .catch(error => console.error("Error during login:", error));
});
document.querySelector("#post-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const title = document.querySelector("#post-title").value;
  const content = document.querySelector("#post-content").value;

  fetch("/dashboard", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ title, content })
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      window.location.href = "/dashboard";
    } else {
      alert("Error creating post");
    }
  })
  .catch(error => console.error("Error creating post:", error));
});
document.querySelectorAll(".delete-post").forEach(button => {
  button.addEventListener("click", (event) => {
    event.preventDefault();
    const postId = button.getAttribute("data-id");

    fetch(`/delete/${postId}`, {
      method: "POST"
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        window.location.href = "/dashboard";
      } else {
        alert("Error deleting post");
      }
    })
    .catch(error => console.error("Error deleting post:", error));
  });
});
document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.getElementById("darkToggle");

  toggle?.addEventListener("click", () => {
    document.body.classList.toggle("dark");
    localStorage.setItem("theme", document.body.classList.contains("dark") ? "dark" : "light");
  });
  // Load saved theme
  if (localStorage.getItem("theme") === "dark") {
    document.body.classList.add("dark");
  }
});
