const express = require("express");
const router = express.Router();
const Post = require("../models/Post");

let isLoggedIn = false;

// Home
router.get("/", async (req, res) => {
  const posts = await Post.find().sort({ date: -1 });
  res.render("index", { posts });
});

// Single Post
router.get("/post/:id", async (req, res) => {
  const post = await Post.findById(req.params.id);
  res.render("post", { post });
});

// Login Page
router.get("/login", (req, res) => {
  res.render("login");
});

// Login Post
router.post("/login", (req, res) => {
  const { username, password } = req.body;
  if (username === "admin" && password === "admin123") {
    isLoggedIn = true;
    res.redirect("/dashboard");
  } else {
    res.send("Invalid credentials");
  }
});

// Dashboard
router.get("/dashboard", (req, res) => {
  if (isLoggedIn) {
    res.render("dashboard");
  } else {
    res.redirect("/login");
  }
});

// Handle post submission
router.post("/dashboard", async (req, res) => {
  const { title, content } = req.body;
  const post = new Post({ title, content });
  await post.save();
  res.redirect("/");
});

// Delete Post
router.post("/delete/:id", async (req, res) => {
  if (isLoggedIn) {
    await Post.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } else {
    res.status(403).json({ success: false, message: "Unauthorized" });
  }
});

// likes
router.post("/like/:id", async (req, res) => {
  await Post.findByIdAndUpdate(req.params.id, { $inc: { likes: 1 } });
  res.redirect(`/post/${req.params.id}`);
});

// Add Comment
router.post("/comment/:id", async (req, res) => {
  const { text } = req.body;
  await Post.findByIdAndUpdate(req.params.id, {
    $push: { comments: { text } }
  });
  res.redirect(`/post/${req.params.id}`);
});

// Logout
router.get("/logout", (req, res) => {
  isLoggedIn = false;
  res.redirect("/");
});

// Export the router
module.exports = router;